document.addEventListener('DOMContentLoaded', () => {
    // --- VARIABEL KONSTANTA ---
    const MAX_HP = 10;
    const TIME_PER_QUESTION = 6.0;
    
    // --- VARIABEL STATUS GAME ---
    let currentAnswer;
    let playerHP = MAX_HP;
    let enemyHP = MAX_HP;
    let gameActive = false;
    let timeLeft = TIME_PER_QUESTION;
    let timerInterval;

    // --- REFERENSI DOM ---
    const DOM = {
        questionArea: document.getElementById('question-area'),
        answerInput: document.getElementById('answer-input'),
        submitBtn: document.getElementById('submit-btn'),
        messageElement: document.getElementById('message'),
        startBtn: document.getElementById('start-btn'),
        playerWizardElement: document.getElementById('player-wizard'),
        enemyWizardElement: document.getElementById('enemy-wizard'),
        fireballElement: document.getElementById('fireball'),
        playerHPBar: document.getElementById('player-hp-bar'),
        playerHPText: document.getElementById('player-hp-text'),
        enemyHPBar: document.getElementById('enemy-hp-bar'),
        enemyHPText: document.getElementById('enemy-hp-text'),
        timeLeftElement: document.getElementById('time-left')
    };

    // --- FUNGSI TIMER ---
    const startTimer = () => {
        clearInterval(timerInterval);
        timeLeft = TIME_PER_QUESTION;
        DOM.timeLeftElement.textContent = timeLeft.toFixed(1);

        timerInterval = setInterval(() => {
            if (!gameActive) {
                clearInterval(timerInterval);
                return;
            }

            timeLeft -= 0.1;
            timeLeft = Math.max(0, timeLeft); 
            DOM.timeLeftElement.textContent = timeLeft.toFixed(1);

            if (timeLeft <= 0) {
                clearInterval(timerInterval);
                checkAnswer(true); // Waktu Habis
            }
        }, 100);
    };

    // --- FUNGSI UTAMA GAME ---
    const updateHPDisplay = () => {
        DOM.playerHPBar.value = playerHP;
        DOM.playerHPText.textContent = `${playerHP}/${MAX_HP}`;
        
        DOM.enemyHPBar.value = enemyHP;
        DOM.enemyHPText.textContent = `${enemyHP}/${MAX_HP}`;

        if (playerHP <= 0) {
            endGame('defeat');
        } else if (enemyHP <= 0) {
            endGame('win');
        }
    };

    const startGame = () => {
        playerHP = MAX_HP;
        enemyHP = MAX_HP;
        gameActive = true;

        DOM.startBtn.classList.add('hidden');
        DOM.answerInput.classList.remove('hidden');
        DOM.submitBtn.classList.remove('hidden');
        DOM.messageElement.classList.add('hidden');
        DOM.answerInput.disabled = false;
        DOM.submitBtn.disabled = false;
        
        // Reset Fireball
        DOM.fireballElement.classList.add('fireball-reset');
        void DOM.fireballElement.offsetWidth; // Memicu reflow/render ulang
        DOM.fireballElement.classList.remove('fireball-reset');

        updateHPDisplay();
        generateQuestion();
    };

    const endGame = (result) => {
        clearInterval(timerInterval);
        gameActive = false;
        DOM.answerInput.disabled = true;
        DOM.submitBtn.disabled = true;
        DOM.timeLeftElement.textContent = '0.0';
        
        DOM.fireballElement.classList.add('fireball-reset');
        DOM.fireballElement.onanimationend = null;

        if (result === 'win') {
            showMessage('KEMENANGAN! Penyihir Lawan Dikalahkan! 🏆', 'correct');
        } else {
            showMessage('KEKALAHAN! HP Anda Habis! Coba Lagi. 💔', 'incorrect');
        }
        
        DOM.startBtn.textContent = 'Mulai Duel Baru!';
        DOM.startBtn.classList.remove('hidden');
    };

    // --- FUNGSI ANIMASI SERANGAN YANG FLEKSIBEL ---

    const animateHit = (targetElement) => {
        if (!gameActive) return; 
        targetElement.classList.add('shake');
        setTimeout(() => {
            targetElement.classList.remove('shake');
        }, 500); 
    };

    /**
     * Mengatur animasi serangan sihir dua tahap (Attack Move Wizard + Fireball Move/Hit).
     */
    const performAttack = (attackerElement, targetElement, isSuccessful) => {
        if (!gameActive) return;

        // 1. Wizard 'Mengambil Jarak' (Attack Move)
        attackerElement.classList.add('attack'); 

        const isPlayerAttacking = attackerElement === DOM.playerWizardElement;
        
        // Reset Fireball sebelum dipakai
        DOM.fireballElement.classList.add('fireball-reset');
        void DOM.fireballElement.offsetWidth; 
        DOM.fireballElement.classList.remove('fireball-reset');
        
        if (isSuccessful && isPlayerAttacking) {
            // KONDISI 1: PLAYER BERHASIL MENYERANG (Meluncurkan Fireball)
            
            // 2. Mulai Animasi Stage 1
            DOM.fireballElement.classList.add('fireball-start');
            
            // Listener untuk tahap 1 selesai
            DOM.fireballElement.onanimationend = (e) => {
                if (e.animationName === 'fireball-stage1') {
                    // 3. Stage 1 selesai, Mulai Animasi Stage 2
                    DOM.fireballElement.classList.remove('fireball-start');
                    DOM.fireballElement.classList.add('fireball-finish');

                    // Listener untuk tahap 2 selesai (Mengenai Target)
                    DOM.fireballElement.onanimationend = (e2) => {
                        if (e2.animationName === 'fireball-stage2') {
                            // 4. Fireball Mengenai Target
                            DOM.fireballElement.classList.remove('fireball-finish');
                            DOM.fireballElement.classList.add('fireball-reset'); 
                            
                            animateHit(targetElement); // Panggil guncangan target
                            
                            DOM.fireballElement.onanimationend = null; 
                        }
                    };
                }
            };
        } else {
            // KONDISI 2 & 3: MUSUH MENYERANG BALIK / Serangan Player Gagal
            
            // Menambahkan jeda (timing) agar guncangan sinkron dengan animasi attack musuh
            const hitDelay = 500; 
            
            setTimeout(() => {
                animateHit(targetElement); // Target terkena guncangan
            }, hitDelay); 
        }
        
        // 5. Wizard Selesai Mengambil Jarak (Lepas class .attack)
        setTimeout(() => {
            attackerElement.classList.remove('attack');
        }, 300); // Sesuai durasi CSS .attack
    };

    // --- FUNGSI SOAL DAN JAWABAN ---

    const generateQuestion = () => {
        if (!gameActive) return;

        const num1 = Math.floor(Math.random() * 50) + 1;
        const num2 = Math.floor(Math.random() * 50) + 1;
        
        currentAnswer = num1 + num2;
        DOM.questionArea.textContent = `${num1} + ${num2} = ?`;
        
        DOM.answerInput.value = '';
        DOM.answerInput.focus();
        
        startTimer(); 
    };

    const checkAnswer = (timeIsUp = false) => {
        if (!gameActive) return;

        clearInterval(timerInterval);
        
        const userAnswer = parseInt(DOM.answerInput.value);
        
        if (isNaN(userAnswer) && !timeIsUp) {
            showMessage('Masukkan angka!', 'incorrect');
            startTimer();
            return;
        }
        
        DOM.answerInput.disabled = true;
        DOM.submitBtn.disabled = true;
        
        let attacker, target, success;

        if (userAnswer === currentAnswer && !timeIsUp) {
            // Player Attack: Jawaban Benar
            enemyHP--;
            showMessage('MANTRA BERHASIL! Lawan Terkena Serangan! 🔥', 'correct');
            attacker = DOM.playerWizardElement;
            target = DOM.enemyWizardElement;
            success = true; 
        } else {
            // Enemy Attack: Jawaban Salah atau Waktu Habis
            playerHP--;
            if (timeIsUp) {
                showMessage(`WAKTU HABIS! Jawaban benar: ${currentAnswer}. Anda Terkena Serangan! 💔`, 'incorrect');
            } else {
                showMessage(`MANTRA GAGAL! Jawaban benar: ${currentAnswer}. Anda Terkena Serangan! 🛡️`, 'incorrect');
            }
            attacker = DOM.enemyWizardElement; 
            target = DOM.playerWizardElement;
            success = false; 
        }
        
        performAttack(attacker, target, success);
        updateHPDisplay();

        // Tunggu hingga semua animasi selesai
        setTimeout(() => {
            if (gameActive) {
                generateQuestion();
                DOM.answerInput.disabled = false;
                DOM.submitBtn.disabled = false;
            }
        }, 1200); 
    };

    const showMessage = (text, type) => {
        DOM.messageElement.textContent = text;
        DOM.messageElement.className = ''; 
        DOM.messageElement.classList.add(type);
        DOM.messageElement.classList.remove('hidden');
    };

    // --- INISIALISASI DAN EVENT LISTENERS ---

    // Sembunyikan input dan submit saat start
    DOM.answerInput.classList.add('hidden');
    DOM.submitBtn.classList.add('hidden');

    DOM.startBtn.addEventListener('click', startGame);
    DOM.submitBtn.addEventListener('click', () => checkAnswer(false));

    DOM.answerInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            checkAnswer(false);
        }
    });

    updateHPDisplay();
});